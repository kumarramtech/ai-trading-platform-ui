# RAM — Risk & Alpha Monitor

Premium RAM dashboard built directly from the supplied working `src` project.

## Important
The API client intentionally remains under `/api` and keeps the existing paper-trading endpoints. If your current working project already has a Vite proxy, keep that existing proxy configuration rather than replacing it.

## Run
Use the same root `package.json` and Vite configuration from the currently working project, then replace its `src/` directory with this project's `src/` directory.

If you use the included package.json, add your existing API proxy configuration for `/api` to the backend gateway.


## RAM API Configuration

The dashboard connects directly to the existing Spring API at `http://localhost:8082` by default. The paper-trading endpoints are used without an `/api` prefix:

- `GET /paper-trades/pnldashboard`
- `GET /paper-trades/pnl?fromDate=YYYY-MM-DD&toDate=YYYY-MM-DD`
- `GET /paper-trades/daily-pnl`
- `GET /paper-trades/open-positions`
- `GET /paper-trades/history`
- `GET /paper-trades/historycustomdates?fromDate=YYYY-MM-DD&toDate=YYYY-MM-DD`

If the backend port changes, set `VITE_API_BASE_URL` in a `.env` file and restart Vite.
