import React from "react";
import { Card, Box, Typography } from "@mui/material";

export default function StatCard({ label, value, detail, icon, tone = "" }) {
  return (
    <Card className={`stat ${tone}`}>
      <Box className="statIcon">{icon}</Box>
      <Box className="statBody">
        <Typography className="statLabel">{label}</Typography>
        <Typography className={`statValue ${tone}`}>{value}</Typography>
        <Typography className="statDetail">{detail}</Typography>
      </Box>
      <Box className="sparkline"><i/><i/><i/><i/><i/></Box>
    </Card>
  );
}
